const HtmlWebpackPlugin = require("html-webpack-plugin");
const { ModuleFederationPlugin } = require("webpack").container;
const path = require("path");

const foundationShared = {
  "@foundation/portal": { singleton: true, eager: true, requiredVersion: false },
  "@foundation/common": { singleton: true, eager: true, requiredVersion: false },
  "@foundation/communication": { singleton: true, eager: true, requiredVersion: false },

  "@foundation/form-designer": { singleton: true, eager: true, requiredVersion: false },
  "@foundation/form-renderer": { singleton: true, eager: true, requiredVersion: false },
  "@foundation/form-theme": { singleton: true, eager: true, requiredVersion: false },

  "@foundation/dashboard": { singleton: true, eager: true, requiredVersion: false },
  "@foundation/i18n": { singleton: true, eager: true, requiredVersion: false },
  "@foundation/cube": { singleton: true, eager: true, requiredVersion: false },
  "@foundation/query": { singleton: true, eager: true, requiredVersion: false },
  "@foundation/ui": { singleton: true, eager: true, requiredVersion: false },
};

module.exports = {
  entry: "./apps/shell/src/main.tsx",
  mode: "development",
  devtool: "source-map",

  output: {
    path: path.resolve(__dirname, "dist"),
    publicPath: "auto",
    clean: true,
    filename: "[name].[contenthash].js",
  },

  resolve: {
    extensions: [".tsx", ".ts", ".js"],
    alias: {
      "@foundation/portal": path.resolve(__dirname, "../../libs/portal/src"),
      "@foundation/common": path.resolve(__dirname, "../../libs/common/src"),
      "@foundation/communication": path.resolve(__dirname, "../../libs/communication/src"),
      "@foundation/form-designer": path.resolve(__dirname, "../../libs/form/designer/src"),
      "@foundation/form-renderer": path.resolve(__dirname, "../../libs/form/renderer/src"),
      "@foundation/form-theme": path.resolve(__dirname, "../../libs/form/theme/src"),
      "@foundation/dashboard": path.resolve(__dirname, "../../libs/dashboard/src"),
      "@foundation/i18n": path.resolve(__dirname, "../../libs/i18n/src"),
      "@foundation/component": path.resolve(__dirname, "../../libs/component/src"),
      "@foundation/cube": path.resolve(__dirname, "../../libs/cube/src"),
      "@foundation/query": path.resolve(__dirname, "../../libs/query/src"),
      "@foundation/ui": path.resolve(__dirname, "../../libs/ui/src"),
    },
  },

  module: {
    rules: [
      {
        oneOf: [
          // ✅ SVGs → raw source (for sprite system)
          {
            test: /\.svg$/,
            type: "asset/source",
          },

          // ✅ TS / TSX
          {
            test: /\.tsx?$/,
            loader: "ts-loader",
            options: { transpileOnly: true },
            exclude: /node_modules/,
          },
        ],
      },
    ],
  },

  experiments: {
    topLevelAwait: true,
  },

  plugins: [
    new ModuleFederationPlugin({
      name: "shell",
      filename: "remoteEntry.js",

      shared: {
        "reflect-metadata": { singleton: true, eager: true },
        react: { singleton: true, eager: true, requiredVersion: false },
        "react-dom": { singleton: true, eager: true, requiredVersion: false },
        "react-router-dom": { singleton: true, eager: true, requiredVersion: false },
        "react/jsx-runtime": { singleton: true, eager: true, requiredVersion: false },

        ...foundationShared,
      },
    }),

    new HtmlWebpackPlugin({
      template: "apps/shell/public/index.html",
    }),
  ],

  devServer: {
    port: 3000,
    historyApiFallback: true,
    static: {
      directory: path.join(__dirname, "public"),
    },
    headers: { "Access-Control-Allow-Origin": "*" },
    hot: true,
    allowedHosts: "all",
  },
};

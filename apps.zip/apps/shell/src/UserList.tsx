import React, { useState } from "react";
import { Feature } from "@foundation/portal";
import { Link, useNavigate } from "react-router-dom";
import { useAction, useCommands } from '@foundation/ui';
import { DialogBuilder } from '@foundation/ui';

// Mock user data
const USERS = [
  { id: 1, name: "John Doe", email: "john@example.com", role: "Admin", status: "Active" },
  { id: 2, name: "Jane Smith", email: "jane@example.com", role: "User", status: "Active" },
  { id: 3, name: "Bob Johnson", email: "bob@example.com", role: "User", status: "Inactive" },
  { id: 4, name: "Alice Brown", email: "alice@example.com", role: "Manager", status: "Active" },
  { id: 5, name: "Charlie Wilson", email: "charlie@example.com", role: "User", status: "Pending" },
];


async function showConfirm() {
  const result = await new DialogBuilder()
    .title('Delete Item')
    .icon("info")
    .message('Are you sure you want to delete this item?')
    .okCancel()
    .show();

  if (result) {
    console.log('User clicked OK');
  } else {
    console.log('User cancelled');
  }
}



function UserListContent() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("All");

  const filteredUsers = USERS.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "All" || user.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const handleUserClick = (userId: number) => {
    navigate(`/users/${userId}`);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active": return "#22c55e";
      case "Inactive": return "#ef4444"; 
      case "Pending": return "#f59e0b";
      default: return "#6b7280";
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case "Admin": return "#8b5cf6";
      case "Manager": return "#3b82f6";
      case "User": return "#6b7280";
      default: return "#6b7280";
    }
  };

  function throwError() : string {
    throw new Error("This is a test error");
  }

  const errorAction = useAction(() => {throw new Error("This is a test error")})

  // useCommands automatically inherits global interceptors from CommandProvider
  const commands = useCommands({
    commands: [
      {
        name: 'confirm',
        label: 'Confirm',
        shortcut: 'Enter',
        run: async () => showConfirm(),
      },
      {
        name: 'cancel',
        label: 'Cancel',
        shortcut: 'Escape',
        run: async () => alert('Cancelled'),
      },
      {
        name: 'error',
        label: 'Error',
        run: () => {
          console.log("###### OUCH - throwing error in command")
          throw Error("ouch from command")
        },
      },
    ],
  });

  const confirm = commands.get("confirm")
  const error = commands.get('error');

  return (
    <div
      style={{
        padding: '24px',
        backgroundColor: '#1a1a1a',
        color: '#e0e0e0',
        minHeight: '100vh',
      }}
    >
      {/* Header */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '24px',
          paddingBottom: '16px',
          borderBottom: '1px solid #333',
        }}
      >
        <div>
          <h1
            style={{
              margin: 0,
              fontSize: '32px',
              fontWeight: '700',
              color: '#fff',
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
            }}
          >
            👥 User Management
            <button onClick={() => throwError()}>ERROR</button>
            <button onClick={errorAction}>ACTION</button>
            <button onClick={confirm}>CONFIRM</button>
            <button onClick={error}>ERROR COMMAND</button>
          </h1>
          <p
            style={{
              margin: '8px 0 0 0',
              fontSize: '16px',
              color: '#a0a0a0',
            }}
          >
            Manage system users and their permissions
          </p>
        </div>

        <button
          style={{
            padding: '12px 24px',
            backgroundColor: '#3b82f6',
            color: '#fff',
            border: 'none',
            borderRadius: '8px',
            fontSize: '14px',
            fontWeight: '600',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            transition: 'background-color 0.2s',
          }}
          onMouseEnter={(e) =>
            (e.currentTarget.style.backgroundColor = '#2563eb')
          }
          onMouseLeave={(e) =>
            (e.currentTarget.style.backgroundColor = '#3b82f6')
          }
        >
          <span>+</span> Add User
        </button>
      </div>

      {/* Filters */}
      <div
        style={{
          display: 'flex',
          gap: '16px',
          marginBottom: '24px',
          flexWrap: 'wrap',
          alignItems: 'center',
        }}
      >
        <div style={{ flex: '1', minWidth: '200px' }}>
          <input
            type="text"
            placeholder="Search users..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{
              width: '100%',
              padding: '12px 16px',
              backgroundColor: '#2a2a2a',
              border: '1px solid #404040',
              borderRadius: '8px',
              color: '#e0e0e0',
              fontSize: '14px',
              outline: 'none',
            }}
            onFocus={(e) => (e.currentTarget.style.borderColor = '#3b82f6')}
            onBlur={(e) => (e.currentTarget.style.borderColor = '#404040')}
          />
        </div>

        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          style={{
            padding: '12px 16px',
            backgroundColor: '#2a2a2a',
            border: '1px solid #404040',
            borderRadius: '8px',
            color: '#e0e0e0',
            fontSize: '14px',
            cursor: 'pointer',
            outline: 'none',
          }}
        >
          <option value="All">All Status</option>
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
          <option value="Pending">Pending</option>
        </select>
      </div>

      {/* Users Table */}
      <div
        style={{
          backgroundColor: '#0d0d0d',
          border: '1px solid #333',
          borderRadius: '12px',
          overflow: 'hidden',
        }}
      >
        {/* Table Header */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '2fr 2fr 1fr 1fr 120px',
            gap: '16px',
            padding: '16px 24px',
            backgroundColor: '#1a1a1a',
            borderBottom: '1px solid #333',
            fontSize: '14px',
            fontWeight: '600',
            color: '#a0a0a0',
          }}
        >
          <div>NAME</div>
          <div>EMAIL</div>
          <div>ROLE</div>
          <div>STATUS</div>
          <div>ACTIONS</div>
        </div>

        {/* Table Body */}
        {filteredUsers.length === 0 ? (
          <div
            style={{
              padding: '48px 24px',
              textAlign: 'center',
              color: '#6b7280',
            }}
          >
            <div style={{ fontSize: '48px', marginBottom: '16px' }}>👤</div>
            <p>No users found</p>
          </div>
        ) : (
          filteredUsers.map((user, index) => (
            <div
              key={user.id}
              style={{
                display: 'grid',
                gridTemplateColumns: '2fr 2fr 1fr 1fr 120px',
                gap: '16px',
                padding: '20px 24px',
                backgroundColor: index % 2 === 0 ? '#0d0d0d' : '#1a1a1a',
                borderBottom:
                  index === filteredUsers.length - 1
                    ? 'none'
                    : '1px solid #333',
                cursor: 'pointer',
                transition: 'background-color 0.2s',
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.backgroundColor = '#2a2a2a')
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.backgroundColor =
                  index % 2 === 0 ? '#0d0d0d' : '#1a1a1a')
              }
              onClick={() => handleUserClick(user.id)}
            >
              <div
                style={{
                  color: '#fff',
                  fontSize: '16px',
                  fontWeight: '500',
                }}
              >
                {user.name}
              </div>

              <div
                style={{
                  color: '#a0a0a0',
                  fontSize: '14px',
                }}
              >
                {user.email}
              </div>

              <div>
                <span
                  style={{
                    padding: '4px 8px',
                    backgroundColor: getRoleColor(user.role) + '20',
                    border: `1px solid ${getRoleColor(user.role)}`,
                    borderRadius: '4px',
                    fontSize: '12px',
                    fontWeight: '500',
                    color: getRoleColor(user.role),
                  }}
                >
                  {user.role}
                </span>
              </div>

              <div>
                <span
                  style={{
                    padding: '4px 8px',
                    backgroundColor: getStatusColor(user.status) + '20',
                    border: `1px solid ${getStatusColor(user.status)}`,
                    borderRadius: '4px',
                    fontSize: '12px',
                    fontWeight: '500',
                    color: getStatusColor(user.status),
                  }}
                >
                  {user.status}
                </span>
              </div>

              <div
                style={{
                  display: 'flex',
                  gap: '8px',
                }}
              >
                <Link
                  to={`/users/${user.id}`}
                  onClick={(e) => e.stopPropagation()}
                  style={{
                    padding: '6px 12px',
                    backgroundColor: '#3b82f6',
                    color: '#fff',
                    textDecoration: 'none',
                    borderRadius: '4px',
                    fontSize: '12px',
                    fontWeight: '500',
                    transition: 'background-color 0.2s',
                  }}
                  onMouseEnter={(e) =>
                    (e.currentTarget.style.backgroundColor = '#2563eb')
                  }
                  onMouseLeave={(e) =>
                    (e.currentTarget.style.backgroundColor = '#3b82f6')
                  }
                >
                  View
                </Link>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Stats Footer */}
      <div
        style={{
          marginTop: '24px',
          padding: '16px 24px',
          backgroundColor: '#0d0d0d',
          border: '1px solid #333',
          borderRadius: '8px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}
      >
        <div style={{ color: '#a0a0a0', fontSize: '14px' }}>
          Showing {filteredUsers.length} of {USERS.length} users
        </div>
        <div style={{ display: 'flex', gap: '16px', fontSize: '14px' }}>
          <span style={{ color: '#22c55e' }}>
            ● {USERS.filter((u) => u.status === 'Active').length} Active
          </span>
          <span style={{ color: '#ef4444' }}>
            ● {USERS.filter((u) => u.status === 'Inactive').length} Inactive
          </span>
          <span style={{ color: '#f59e0b' }}>
            ● {USERS.filter((u) => u.status === 'Pending').length} Pending
          </span>
        </div>
      </div>
    </div>
  );
}

@Feature({
  id: "users",
  i18n: "users",
  label: "Users",
  path: "/users",
  icon: "shell:add",
  description: "User management system - list all users",
  tags: ["menu"],
  permissions: ["user:read"],
  features: ["list", "search", "filter"],
  visibility: ["public", "private"]
})
class UserList extends React.Component {
  render() {
    return <UserListContent />;
  }
}

export default UserList;
import "reflect-metadata";
import React from "react";

import {
    DeploymentManager,
    EnvironmentContext,
    RouterManager,
} from "@foundation/portal";

import { CommandProvider } from "@foundation/ui";
import { Environment, ErrorManager } from '@foundation/common';
import { I18NProvider } from '@foundation/portal';


export class App extends React.Component {
    state = {ready: false};
    routerManager!: RouterManager;

    static contextType = EnvironmentContext

    declare context: Environment

    async componentDidMount() { 
        this.routerManager = this.context.get(RouterManager);
        const deploymentManager = this.context.get(DeploymentManager);

        deploymentManager.checkLazyFeatures('shell', import.meta.webpackContext('./', { 
                recursive: true, 
                regExp: /\.tsx$/ 
            }
        )); 

        // mark ready

        this.setState({ready: true});
    }

    render() {
        if (!this.state.ready) return <div>Loading application…</div>;

        // render the router with lazy FeatureOutlets

        return (
          <I18NProvider>
            <CommandProvider
                handleError={this.context.get(ErrorManager).handle}
                /*initialCommands={[
                    { name: "save", label: "Save", shortcut: "ctrl+s", run: async () => console.log("Saved") },
                    { name: "delete", label: "Delete", shortcut: "Delete", run: async () => console.log("Deleted") },
                ]}*/
            >
                {this.routerManager.renderRouter()}
            </CommandProvider>
            </I18NProvider>
        );
    }
}

export default App;

import 'reflect-metadata';

import { createRoot } from 'react-dom/client';
import App from './App';

import { SvgSpriteRegistry } from '@foundation/ui';

import {
  AbstractModule,
  DeploymentManager,
  ServiceDeploymentLoader,
  RemoteDeploymentLoader,
  Module,
  Manifest,
  ManifestProcessor,
  FeatureRegistry,
  RouterManager,
  EnvironmentContext,
  DeploymentLoader,
  EmptyDeploymentLoader,
  LocalComponentLoader
} from '@foundation/portal';

import { AssetTranslationLoader, LocaleManager, LocalStorageLocaleBackingStore, Translator, TranslatorBuilder } from '@foundation/i18n';

import { PortalService, RemoteComponentLoader, ComponentLoader, I18NLoader } from '@foundation/portal';

import {
  TraceLevel,
  Tracer,
  ConsoleTrace,
  ConfigurationManager,
  ValueConfigurationSource,
  catchError,
  Environment,
  create,
  onRunning,
  injectable,
  TypeDescriptor,
} from '@foundation/common';

import {
  EndpointLocator,
  PatternEndpointLocator,
  Serialization,
} from '@foundation/communication';

import manifest from './manifest.json';

import {
  KeycloakAuthenticationService,
  SessionManager,
} from '@foundation/portal';

// tracing

new Tracer({
  enabled: true,
  trace: new ConsoleTrace('%d [%p]: %m\n'), // %f
  paths: {
    application: TraceLevel.FULL,
    di: TraceLevel.OFF,
    portal: TraceLevel.OFF,
    form: TraceLevel.OFF,
  },
});

// serialization

new Serialization();

import './Navigation';
import './DashboardFeature';
import './ChatPanel';
import './CubeConfigurator';
import './PublicNavigation';
import './Navigation';

// import editor stuff

import '@foundation/query/editor/property-editor/query-expression-editor';
import '@foundation/query/editor/search-panel-property-editor';
import '@foundation/cube/form/cube-widget-configuration-editor';

// application module

@Module({
  id: 'shell',
  label: 'Shell',
  version: '1.0.0',
  description: 'Shell',
  name: '',
})
@injectable({module: "shell"})
export class ApplicationModule extends AbstractModule {
  @create()
  createSessionManager() : SessionManager<any,any> {
    return new SessionManager(new KeycloakAuthenticationService());
  }

  @create()
  createLocaleManager() : LocaleManager {
    return new LocaleManager({
      locale: "de-DE",
      supportedLocales: ["de-DE", "en-US"],
      backingStore: new LocalStorageLocaleBackingStore("language"),
    })
  }

  @create()
  createTranslator(localeManager: LocaleManager) : Translator {
    return new TranslatorBuilder()
      .loader(new AssetTranslationLoader({ path: '/i18n/' }))
      .localeManager(localeManager)
      .build()
  }

  @create()
  createConfigurationManager() : ConfigurationManager {
    return new ConfigurationManager(
      new ValueConfigurationSource({
        foo: {
          bar: 'bar',
        },
      }),
    );
  }

  @create()
  createDeploymentLoader(portalService: PortalService) : DeploymentLoader {
    let load = 'remote';

    if (load == 'service') 
      return new ServiceDeploymentLoader(portalService);

    else if (load == 'remote')
      return new RemoteDeploymentLoader([
        { name: 'mfe1', url: 'http://localhost:3001' },
      ]);
    
      else return new EmptyDeploymentLoader()
  }

  @create()
  createDeploymentManager(loader: DeploymentLoader, featureRegistry: FeatureRegistry) : DeploymentManager {
      return new DeploymentManager(
        featureRegistry,
        loader,
        manifest as unknown as Manifest,
        new ManifestProcessor(),

        (permission: string) => {
          console.log('check permission ' + permission);
          return true;
        },

        (feature: string) => {
          console.log('check feature ' + feature);
          return true;
        },
      );
  }
  
  @create()
  createEndpointLocator() : EndpointLocator {
      return new PatternEndpointLocator({
          match: '.*',
          url: 'http://localhost:8000/',
        })
  }

    // lifecycle

    @onRunning()
    async onRunning(featureRegistry: FeatureRegistry, deploymentManager: DeploymentManager, sessionManager: SessionManager<any,any>, routerManager: RouterManager) {
      // load deployment

      await deploymentManager.loadDeployment({
          application: "portal",
          client: deploymentManager.clientInfo(),
      });

      // set root

      routerManager.setRoot(featureRegistry.finder()
        .withTag('portal')
        .withVisibility(sessionManager.hasSession())
        .findOne()
        );
    }

  // error handlers

  @catchError()
  public handleError(error: any) {
    console.log(error)
  }

  // lifecycle methods

  async setup() : Promise<void>  {
    // setup tracer

    Tracer.Trace('application', TraceLevel.LOW, 'setup');

    // sprites

    this.get(SvgSpriteRegistry).registerAll("shell", import.meta.webpackContext(
        './icons',
         { 
          recursive: false, 
          regExp: /\.svg$/ 
        }
       ));

    // session manager

    await this.get(SessionManager).init();

    // done

    await super.setup();
  }
}

// import loaders

const loaders = [RemoteComponentLoader, LocalComponentLoader, I18NLoader]

// create environment

console.log("### start application")

const environment = new Environment({module: ApplicationModule})

const td = TypeDescriptor.forType(ApplicationModule)

console.log(environment.report())

await environment.start()

// crate app

const rootElement = document.getElementById('root');

if (!rootElement) throw new Error('Root container not found');

const root = createRoot(rootElement);
root.render(
    <EnvironmentContext.Provider value={environment}>
      <App />
    </EnvironmentContext.Provider>);

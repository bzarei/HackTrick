import React from "react";
import { Feature } from "@foundation/portal";
import {WidgetEditor} from "@foundation/form-designer";

@Feature({
  id: "dashboard",
  label: "Dashboard Configurator",
  path: "/dashboard",
  icon: "shell:add",
  description: "Dashboard configuration and analysis tool",
  tags: ["menu"],
  permissions: [],
  features: [],
  visibility: ["private"]
})
class DashboardConfiguratorFeature extends React.Component {
  render() {
    return <WidgetEditor/>;
  }
}

export default DashboardConfiguratorFeature;
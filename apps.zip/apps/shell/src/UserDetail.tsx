import React, { useState } from "react";
import { Feature } from "@foundation/portal";
import {useParams, useNavigate, Link, Outlet} from "react-router-dom";

// Mock user data (same as in UserList)
const USERS = [
  { id: 1, name: "John Doe", email: "john@example.com", role: "Admin", status: "Active", 
    avatar: "👨‍💼", joinDate: "2023-01-15", lastLogin: "2024-01-08", department: "IT" },
  { id: 2, name: "Jane Smith", email: "jane@example.com", role: "User", status: "Active",
    avatar: "👩‍💻", joinDate: "2023-03-22", lastLogin: "2024-01-09", department: "Marketing" },
  { id: 3, name: "Bob Johnson", email: "bob@example.com", role: "User", status: "Inactive",
    avatar: "👨‍🔧", joinDate: "2023-06-10", lastLogin: "2023-12-20", department: "Operations" },
  { id: 4, name: "Alice Brown", email: "alice@example.com", role: "Manager", status: "Active",
    avatar: "👩‍💼", joinDate: "2023-02-05", lastLogin: "2024-01-09", department: "HR" },
  { id: 5, name: "Charlie Wilson", email: "charlie@example.com", role: "User", status: "Pending",
    avatar: "👨‍💼", joinDate: "2024-01-01", lastLogin: "Never", department: "Sales" },
];

function UserDetailContent() {
  const { userId } = useParams<{ userId: string }>();
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  
  const user = USERS.find(u => u.id === parseInt(userId || "0"));

  if (!user) {
    return (
      <div style={{
        padding: "24px",
        backgroundColor: "#1a1a1a",
        color: "#e0e0e0",
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center"
      }}>
        <div style={{ fontSize: "64px", marginBottom: "16px" }}>❌</div>
        <h1>User Not Found</h1>
        <p style={{ color: "#a0a0a0", marginBottom: "24px" }}>
          The user with ID {userId} could not be found.
        </p>
        <Link
          to="/users"
          style={{
            padding: "12px 24px",
            backgroundColor: "#3b82f6",
            color: "#fff",
            textDecoration: "none",
            borderRadius: "8px",
            fontWeight: "600"
          }}
        >
          ← Back to Users
        </Link>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active": return "#22c55e";
      case "Inactive": return "#ef4444";
      case "Pending": return "#f59e0b";
      default: return "#6b7280";
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case "Admin": return "#8b5cf6";
      case "Manager": return "#3b82f6";
      case "User": return "#6b7280";
      default: return "#6b7280";
    }
  };

  return (
    <div style={{
      padding: "24px",
      backgroundColor: "#1a1a1a",
      color: "#e0e0e0",
      minHeight: "100vh"
    }}>
      {/* Breadcrumb */}
      <nav style={{
        marginBottom: "24px",
        display: "flex",
        alignItems: "center",
        gap: "8px",
        fontSize: "14px",
        color: "#a0a0a0"
      }}>
        <Link
          to="/users"
          style={{ color: "#3b82f6", textDecoration: "none" }}
          onMouseEnter={(e) => e.currentTarget.style.textDecoration = "underline"}
          onMouseLeave={(e) => e.currentTarget.style.textDecoration = "none"}
        >
          Users
        </Link>
        <span>/</span>
        <span style={{ color: "#e0e0e0" }}>{user.name}</span>
      </nav>

      {/* Header */}
      <div style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "flex-start",
        marginBottom: "32px",
        paddingBottom: "24px",
        borderBottom: "1px solid #333"
      }}>
        <div style={{
          display: "flex",
          gap: "20px",
          alignItems: "center"
        }}>
          {/* Avatar */}
          <div style={{
            width: "80px",
            height: "80px",
            borderRadius: "50%",
            backgroundColor: "#2a2a2a",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "40px",
            border: "3px solid #404040"
          }}>
            {user.avatar}
          </div>

          <div>
            <h1 style={{
              margin: 0,
              fontSize: "32px",
              fontWeight: "700",
              color: "#fff"
            }}>
              {user.name}
            </h1>
            <p style={{
              margin: "4px 0 12px 0",
              fontSize: "16px",
              color: "#a0a0a0"
            }}>
              {user.email}
            </p>
            <div style={{
              display: "flex",
              gap: "12px"
            }}>
              <span style={{
                padding: "6px 12px",
                backgroundColor: getRoleColor(user.role) + "20",
                border: `1px solid ${getRoleColor(user.role)}`,
                borderRadius: "6px",
                fontSize: "14px",
                fontWeight: "500",
                color: getRoleColor(user.role)
              }}>
                {user.role}
              </span>
              <span style={{
                padding: "6px 12px",
                backgroundColor: getStatusColor(user.status) + "20",
                border: `1px solid ${getStatusColor(user.status)}`,
                borderRadius: "6px",
                fontSize: "14px",
                fontWeight: "500",
                color: getStatusColor(user.status)
              }}>
                {user.status}
              </span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div style={{
          display: "flex",
          gap: "12px"
        }}>
          <button
            onClick={() => setIsEditing(!isEditing)}
            style={{
              padding: "12px 24px",
              backgroundColor: isEditing ? "#ef4444" : "#3b82f6",
              color: "#fff",
              border: "none",
              borderRadius: "8px",
              fontSize: "14px",
              fontWeight: "600",
              cursor: "pointer",
              transition: "background-color 0.2s"
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = isEditing ? "#dc2626" : "#2563eb";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = isEditing ? "#ef4444" : "#3b82f6";
            }}
          >
            {isEditing ? "Cancel" : "Edit User"}
          </button>

          <button
            style={{
              padding: "12px 24px",
              backgroundColor: "#059669",
              color: "#fff",
              border: "none",
              borderRadius: "8px",
              fontSize: "14px",
              fontWeight: "600",
              cursor: "pointer",
              transition: "background-color 0.2s"
            }}
            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#047857"}
            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "#059669"}
          >
            Save Changes
          </button>
        </div>
      </div>

      {/* User Details */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: "24px"
      }}>
        {/* Basic Information */}
        <div style={{
          backgroundColor: "#0d0d0d",
          border: "1px solid #333",
          borderRadius: "12px",
          padding: "24px"
        }}>
          <h2 style={{
            margin: "0 0 20px 0",
            fontSize: "20px",
            fontWeight: "600",
            color: "#fff"
          }}>
            Basic Information
          </h2>
          
          <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            <div>
              <label style={{
                display: "block",
                fontSize: "14px",
                fontWeight: "500",
                color: "#a0a0a0",
                marginBottom: "8px"
              }}>
                Full Name
              </label>
              <input
                type="text"
                value={user.name}
                disabled={!isEditing}
                style={{
                  width: "100%",
                  padding: "12px 16px",
                  backgroundColor: isEditing ? "#2a2a2a" : "#1a1a1a",
                  border: "1px solid #404040",
                  borderRadius: "8px",
                  color: "#e0e0e0",
                  fontSize: "14px",
                  outline: "none"
                }}
              />
            </div>

            <div>
              <label style={{
                display: "block",
                fontSize: "14px",
                fontWeight: "500",
                color: "#a0a0a0",
                marginBottom: "8px"
              }}>
                Email Address
              </label>
              <input
                type="email"
                value={user.email}
                disabled={!isEditing}
                style={{
                  width: "100%",
                  padding: "12px 16px",
                  backgroundColor: isEditing ? "#2a2a2a" : "#1a1a1a",
                  border: "1px solid #404040",
                  borderRadius: "8px",
                  color: "#e0e0e0",
                  fontSize: "14px",
                  outline: "none"
                }}
              />
            </div>

            <div>
              <label style={{
                display: "block",
                fontSize: "14px",
                fontWeight: "500",
                color: "#a0a0a0",
                marginBottom: "8px"
              }}>
                Department
              </label>
              <select
                value={user.department}
                disabled={!isEditing}
                style={{
                  width: "100%",
                  padding: "12px 16px",
                  backgroundColor: isEditing ? "#2a2a2a" : "#1a1a1a",
                  border: "1px solid #404040",
                  borderRadius: "8px",
                  color: "#e0e0e0",
                  fontSize: "14px",
                  outline: "none",
                  cursor: isEditing ? "pointer" : "default"
                }}
              >
                <option value="IT">IT</option>
                <option value="Marketing">Marketing</option>
                <option value="Operations">Operations</option>
                <option value="HR">HR</option>
                <option value="Sales">Sales</option>
              </select>
            </div>
          </div>
        </div>

        {/* System Information */}
        <div style={{
          backgroundColor: "#0d0d0d",
          border: "1px solid #333",
          borderRadius: "12px",
          padding: "24px"
        }}>
          <h2 style={{
            margin: "0 0 20px 0",
            fontSize: "20px",
            fontWeight: "600",
            color: "#fff"
          }}>
            System Information
          </h2>

          <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            <div>
              <label style={{
                display: "block",
                fontSize: "14px",
                fontWeight: "500",
                color: "#a0a0a0",
                marginBottom: "8px"
              }}>
                User ID
              </label>
              <div style={{
                padding: "12px 16px",
                backgroundColor: "#1a1a1a",
                border: "1px solid #404040",
                borderRadius: "8px",
                color: "#a0a0a0",
                fontSize: "14px"
              }}>
                #{user.id}
              </div>
            </div>

            <div>
              <label style={{
                display: "block",
                fontSize: "14px",
                fontWeight: "500",
                color: "#a0a0a0",
                marginBottom: "8px"
              }}>
                Join Date
              </label>
              <div style={{
                padding: "12px 16px",
                backgroundColor: "#1a1a1a",
                border: "1px solid #404040",
                borderRadius: "8px",
                color: "#a0a0a0",
                fontSize: "14px"
              }}>
                {user.joinDate}
              </div>
            </div>

            <div>
              <label style={{
                display: "block",
                fontSize: "14px",
                fontWeight: "500",
                color: "#a0a0a0",
                marginBottom: "8px"
              }}>
                Last Login
              </label>
              <div style={{
                padding: "12px 16px",
                backgroundColor: "#1a1a1a",
                border: "1px solid #404040",
                borderRadius: "8px",
                color: "#a0a0a0",
                fontSize: "14px"
              }}>
                {user.lastLogin}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Activity Section */}
      <div style={{
        marginTop: "24px",
        backgroundColor: "#0d0d0d",
        border: "1px solid #333",
        borderRadius: "12px",
        padding: "24px"
      }}>
        <h2 style={{
          margin: "0 0 20px 0",
          fontSize: "20px",
          fontWeight: "600",
          color: "#fff"
        }}>
          Recent Activity
        </h2>
        
        <div style={{
          textAlign: "center",
          padding: "40px",
          color: "#6b7280"
        }}>
          <div style={{ fontSize: "48px", marginBottom: "16px" }}>📊</div>
          <p>Activity tracking coming soon...</p>
        </div>
      </div>
    </div>
  );
}

@Feature({
  id: "user-detail",
  label: "User Details",
  path: "/users/:userId",
  parent: "users", // This makes it a child of UserList
  icon: "shell:add",
  description: "User management system - view and edit individual user details", 
  tags: ["users", "management", "admin", "detail"],
  permissions: ["user:read", "user:write"],
  features: ["detail", "edit", "activity"],
  visibility: ["public", "private"]
})
class UserDetail extends React.Component {
  render() {
      return <div><UserDetailContent /><Outlet></Outlet></div>;
  }
}

export default UserDetail;

// CounterWrapper.tsx
import React from "react";

import { Component, prop, h, If, For, ComponentStyle } from "./us";


// SAMPLE

class Counter extends Component {
  @prop count = 0;

  render() {
    return h("div", null,
      h("h2", null, "Counter Sample"),
      h("p", null,
        () => `Count: ${this.count}`
      ),
      h("button", {
        onClick: () => this.count++
      }, "Increment")
    );
  }
}

@ComponentStyle(`
  .btn {
    color: red;
    font-weight: bold;
  }
`)
class TodoList extends Component {
  @prop todos = ["Learn", "Build", "Ship"];
  @prop show = true;

  render() {
    return h("div", null,
      h("button", { 
        class: "btn",
        onClick: () => this.show = !this.show }, "Toggle"),

        h("button", {
                class: "btn",
                onClick: () => this.todos = [...this.todos, "new todo" +  this.todos.length ] }, "Add"),

      If(
        () => this.show,
        () => h("ul", null,
          For(
            () => this.todos,
            todo => h("li", null, () => todo)
          )
        )
      )
    );
  }
}



type Props = {
  initialCount?: number;
  onChange?: (value: number) => void;
};

export class CounterWrapper extends React.Component<Props> {
  private containerRef = React.createRef<HTMLDivElement>();
  private instance: Counter | null = null;

  /* -----------------------------
   * Mount
   * ----------------------------- */
  componentDidMount() {
    const el = this.containerRef.current;
    if (!el) return;

    const instance = new Counter();

    // pass initial props
    if (this.props.initialCount != null) {
      instance.count = this.props.initialCount;
    }

    //instance.onChange = this.props.onChange;

    instance.mount(el);

    this.instance = instance;
  }

  /* -----------------------------
   * Update
   * ----------------------------- */
  componentDidUpdate(prevProps: Props) {
    const inst = this.instance;
    if (!inst) return;

    // sync React → incremental state
    if (prevProps.initialCount !== this.props.initialCount &&
        this.props.initialCount != null) {
      inst.count = this.props.initialCount;
    }

    // update callback reference
    if (prevProps.onChange !== this.props.onChange) {
      //inst.onChange = this.props.onChange;
    }
  }

  /* -----------------------------
   * Unmount
   * ----------------------------- */
  componentWillUnmount() {
    // optional cleanup hook (future-proof)
    if (this.instance && typeof (this.instance as any).dispose === "function") {
      (this.instance as any).dispose(); // TODO?
    }

    this.instance = null;
  }

  /* -----------------------------
   * Render
   * ----------------------------- */
  render() {
    // React owns ONLY this div
    return <div ref={this.containerRef} />;
  }
}
export class TodoWrapper extends React.Component<Props> {
  private containerRef = React.createRef<HTMLDivElement>();
  private instance: TodoList | null = null;

  /* -----------------------------
   * Mount
   * ----------------------------- */
  componentDidMount() {
    const el = this.containerRef.current;
    if (!el) return;

    const instance = new TodoList();

    // pass initial props
    if (this.props.initialCount != null) {
      //instance.count = this.props.initialCount;
    }

    //instance.onChange = this.props.onChange;

    instance.mount(el);

    this.instance = instance;
  }

  /* -----------------------------
   * Update
   * ----------------------------- */
  componentDidUpdate(prevProps: Props) {
    const inst = this.instance;
    if (!inst) return;

    // sync React → incremental state
    if (prevProps.initialCount !== this.props.initialCount &&
        this.props.initialCount != null) {
      //inst.count = this.props.initialCount;
    }

    // update callback reference
    if (prevProps.onChange !== this.props.onChange) {
      //inst.onChange = this.props.onChange;
    }
  }

  /* -----------------------------
   * Unmount
   * ----------------------------- */
  componentWillUnmount() {
    // optional cleanup hook (future-proof)
    if (this.instance && typeof (this.instance as any).dispose === "function") {
      (this.instance as any).dispose(); // TODO?
    }

    this.instance = null;
  }

  /* -----------------------------
   * Render
   * ----------------------------- */
  render() {
    // React owns ONLY this div
    return <div ref={this.containerRef} />;
  }
}
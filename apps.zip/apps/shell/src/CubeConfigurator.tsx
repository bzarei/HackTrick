import React from "react";
import { Feature } from "@foundation/portal";
import { CubePreviewPanel, CubeDescriptor } from "@foundation/cube";
import { CounterWrapper, TodoWrapper  } from "./us-sample";

// Simple wrapper around existing CubePreviewPanel
function CubeConfiguratorContent() {
  const [cube] = React.useState<CubeDescriptor>(() => ({
    id: "sample-cube",
    name: "sample_cube",
    title: "Sample Cube",
    table: "sample_table",
    measures: [],
    dimensions: [],
    segments: [],
    joins: []
  }));
  const [visible, setVisible] = React.useState(true);

  return (
    <div style={{
      height: "100vh",
      backgroundColor: "#0b141a",
      position: "relative"
    }}>
      <div style={{
        padding: "20px",
        color: "#e9edef"
      }}>
        <h1>🧊 Cube Configurator</h1>
        <p>Data cube configuration and analysis tool</p>
      </div>
      
      <CubePreviewPanel
        cube={cube}
        visible={visible}
        onToggle={() => setVisible(!visible)}
      />
    </div>
  );
}

@Feature({
  id: "cube",
  label: "Cube Configurator",
  path: "/cube",
  icon: "shell:add",
  description: "Data cube configuration and analysis tool",
  tags: ["menu"],
  permissions: [],
  features: [],
  visibility: ["private"]
})
class CubeConfiguratorFeature extends React.Component {
  render() {
    //return <CounterWrapper/>;
    return <TodoWrapper/>;
    //<div>
    //  <CounterWrapper></CounterWrapper>TodoWrapper
    //  <TodoWrapper></TodoWrapper>
    // </div>//return <CubeConfiguratorContent />;
  }
}

export default CubeConfiguratorFeature;
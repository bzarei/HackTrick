/* ===============================
 * Reactive core
 * =============================== */

type EffectFn = () => void;

let currentEffect: Effect | null = null;

export class Signal<T> {
  private value: T;
  private subscribers: Set<Effect> = new Set();

  constructor(value: T) {
    this.value = value;
  }

  get(): T {
    if (currentEffect) {
      this.subscribers.add(currentEffect);
      currentEffect.track(this);
    }
    return this.value;
  }

  set(value: T): void {
    if (Object.is(this.value, value)) return;

    this.value = value;

    // Snapshot to prevent infinite loops
    const effects = Array.from(this.subscribers);
    for (const effect of effects) {
      scheduleEffect(effect);
    }
  }

  unsubscribe(effect: Effect): void {
    this.subscribers.delete(effect);
  }
}

export class Effect {
  private deps: Set<Signal<any>> = new Set();
  private fn: EffectFn;

  constructor(fn: EffectFn) {
    this.fn = fn;
    this.run();
  }

  track(signal: Signal<any>) {
    this.deps.add(signal);
  }

  run() {
    // cleanup previous deps
    for (const dep of this.deps) {
      dep.unsubscribe(this);
    }
    
    this.deps.clear();

    currentEffect = this;
    try {
      this.fn();
    } 
    finally {
      currentEffect = null;
    }
  }
}

export function effect(fn: EffectFn): Effect {
  return new Effect(fn);
}

/* ---------- Scheduler ---------- */

const effectQueue = new Set<Effect>();
let isFlushing = false;

function scheduleEffect(effect: Effect) {
  effectQueue.add(effect);

  if (!isFlushing) {
    isFlushing = true;

    queueMicrotask(() => {
      try {
        for (const e of effectQueue) {
          e.run();
        }
      } finally {
        effectQueue.clear();
        isFlushing = false;
      }
    });
  }
}

/* ===============================
 * DOM helpers
 * =============================== */

export function h(
  tag: string,
  props: Record<string, any> | null,
  ...children: any[]
): HTMLElement {
  const el = document.createElement(tag);

  if (props) {
    for (const key in props) {
      const value = props[key];

      if (key.startsWith("on") && typeof value === "function") {
        el.addEventListener(key.slice(2).toLowerCase(), value);
      } else {
        el.setAttribute(key, String(value));
      }
    }
  }

  for (const child of children) {
    append(el, child);
  }

  return el;
}

function append(parent: Node, child: any): void {
  if (child == null || child === false) return;

  if (typeof child === "string" || typeof child === "number") {
    parent.appendChild(document.createTextNode(String(child)));
  } else if (typeof child === "function") {
    const text = document.createTextNode("");
    parent.appendChild(text);

    effect(() => {
      text.data = String(child());
    });
  } else if (child instanceof Node) {
    parent.appendChild(child);
  }
}

/* ===============================
 * Control flow
 * =============================== */
export function If(
  cond: () => boolean,
  thenFn: () => Node,
  elseFn?: () => Node
): Comment {
  const marker = document.createComment("if");
  let current: Node | null = null;

  effect(() => {
    // ✅ READ signals synchronously (tracked!)
    const shouldShow = cond();
    const next = shouldShow ? thenFn() : elseFn?.();

    // ✅ Schedule only DOM updates
    queueMicrotask(() => {
      const parent = marker.parentNode;
      if (!parent) return;

      if (current && current !== next && current.parentNode === parent) {
        parent.removeChild(current);
      }

      current = next ?? null;

      if (current) {
        parent.insertBefore(current, marker.nextSibling);
      }
    });
  });

  return marker;
}


export function For<T>(
  list: () => readonly T[],
  render: (item: T) => Node
): Comment {
  const marker = document.createComment("for");
  let nodes: Node[] = [];

  effect(() => {
    // ✅ Track synchronously
    const items = list();
    const newNodes = items.map(render);

    queueMicrotask(() => {
      const parent = marker.parentNode;
      if (!parent) return;

      for (const node of nodes) {
        if (node.parentNode === parent) parent.removeChild(node);
      }

      nodes = newNodes;

      for (const node of nodes) {
        parent.insertBefore(node, marker.nextSibling);
      }
    });
  });

  return marker;
}



/* ===============================
 * Component base
 * =============================== */

const PROP_KEYS = Symbol("prop_keys");
const STYLE_KEY = Symbol("component_style");
let styleIdCounter = 0;
const injectedStyles = new WeakSet<any>();

export abstract class Component {
  private __propsInitialized = false;

  private __initProps(): void {
    if (this.__propsInitialized) return;
    this.__propsInitialized = true;

    let proto: any = Object.getPrototypeOf(this);

    while (proto) {
      const keys: string[] | undefined = proto[PROP_KEYS];
      if (keys) {
        for (const key of keys) {
          const initialValue = (this as any)[key];
          const signal = new Signal(initialValue);

          Object.defineProperty(this, key, {
            configurable: true,
            enumerable: true,
            get() {
              return signal.get();
            },
            set(value: any) {
              signal.set(value);
            }
          });
        }
      }
      proto = Object.getPrototypeOf(proto);
    }
  }

  mount(parent: HTMLElement): void {
    this.__initProps();
    this.__applyStyle();

    const root = this.render();

    // Apply scope attribute
    const ctor: any = this.constructor;
    if (ctor.__scopeId) {
      root.setAttribute("data-scope", ctor.__scopeId);
    }

    parent.appendChild(root);
  }

private __applyStyle(): void {
  const ctor: any = this.constructor;
  const css: string | undefined = ctor[STYLE_KEY];
  if (!css || injectedStyles.has(ctor)) return;

  const id = "c" + styleIdCounter++;
  ctor.__scopeId = id;

  // Prefix all selectors with [data-scope="id"]
  const scopedCss = css.replace(/(^|\})\s*([^{]+)/g, (_, brace, selector) => {
    if (!selector.trim()) return _;
    // split multiple selectors
    return (
      brace +
      selector
        .split(",")
        .map((s: any) => `[data-scope="${id}"] ${s.trim()}`)
        .join(", ")
    );
  });

  const styleEl = document.createElement("style");
  styleEl.textContent = scopedCss;
  document.head.appendChild(styleEl);
  injectedStyles.add(ctor);
}


  abstract render(): HTMLElement;
}

/* ===============================
 * Decorators
 * =============================== */

export function prop(target: any, key: string): void {
  if (!target[PROP_KEYS]) {
    Object.defineProperty(target, PROP_KEYS, {
      value: [],
      enumerable: false,
      configurable: false,
      writable: false
    });
  }

  target[PROP_KEYS].push(key);
}

export function ComponentStyle(css: string) {
  return function (target: any) {
    target[STYLE_KEY] = css;
  };
}

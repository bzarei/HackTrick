const HtmlWebpackPlugin = require("html-webpack-plugin");
const { ModuleFederationPlugin } = require("webpack").container;
const path = require("path");

const foundationShared = {
   "@foundation/portal": { singleton: true, eager: true, requiredVersion: false },
   "@foundation/common": { singleton: true, eager: true, requiredVersion: false },
   "@foundation/communication": { singleton: true, eager: true, requiredVersion: false },
   "@foundation/i18n": { singleton: true, eager: true, requiredVersion: false },
   "@foundation/ui": { singleton: true, eager: true, requiredVersion: false },
};

module.exports = {
  entry: './apps/mfe1/src/main.tsx',
  mode: 'development',
  devtool: 'source-map',
  devServer: {
    port: 3001,
    static: {
      directory: path.join(__dirname, 'public'),
    },
    headers: {
      'Access-Control-Allow-Origin': '*',
    },
  },
  output: {
    path: path.resolve(__dirname, 'dist'),
    publicPath: 'http://localhost:3001/',
    crossOriginLoading: 'anonymous',
  },
  resolve: {
    extensions: ['.tsx', '.ts', '.js', '.json'],
    alias: {
      '@foundation/portal': path.resolve(process.cwd(), 'libs/portal/src'),
      '@foundation/common': path.resolve(process.cwd(), 'libs/common/src'),
      '@foundation/form': path.resolve(process.cwd(), 'libs/form/src'),
      '@foundation/form-designer': path.resolve(process.cwd(), 'libs/form/designer/src'),
      '@foundation/form-renderer': path.resolve(process.cwd(), 'libs/form/renderer/src'),
      '@foundation/form-theme': path.resolve(process.cwd(), 'libs/form/theme/src'),
      '@foundation/dashboard': path.resolve(process.cwd(), 'libs/dashboard/src'),
      '@foundation/i18n': path.resolve(process.cwd(), 'libs/i18n/src'),
      '@foundation/component': path.resolve(process.cwd(), 'libs/component/src'),
      '@foundation/communication': path.resolve(process.cwd(), 'libs/communication/src'),
      '@foundation/cube': path.resolve(process.cwd(), 'libs/cube/src'),
      '@foundation/query': path.resolve(process.cwd(), 'libs/query/src'),
      '@foundation/ui': path.resolve(process.cwd(), 'libs/ui/src'),
    },
  },
  module: {
    rules: [
      { test: /\.tsx?$/, loader: 'ts-loader' },
      { test: /\.json$/, type: 'json' },
    ],
  },
  plugins: [
    new ModuleFederationPlugin({
      name: 'mfe1',
      filename: 'remoteEntry.js',
      exposes: {
        './MFE1Home': './apps/mfe1/src/MFE1Home',
        './MFE1FooSmall': './apps/mfe1/src/MFE1FooSmall',
        './MFE1FooLarge': './apps/mfe1/src/MFE1FooLarge',
        './MFE1Bar': './apps/mfe1/src/MFE1Bar',
        './DesktopNavigation': './apps/mfe1/src/DesktopNavigation',
        './CapacitorIOSNavigation': './apps/mfe1/src/CapacitorIOSNavigation',
        './Module': './apps/mfe1/src/Module',
      },
      shared: {
        "reflect-metadata": { singleton: true, requiredVersion: false },
        react: { singleton: true, requiredVersion: false },
        'react-dom': { singleton: true, requiredVersion: false },
        'react-router-dom': { singleton: true, requiredVersion: false },
        "react/jsx-runtime": { singleton: true, requiredVersion: false },
        
        ...foundationShared,
      },
    }),
    new HtmlWebpackPlugin({
      template: './apps/mfe1/public/index.html',
    }),
  ],
};

import { injectable } from '@foundation/common';
import { AbstractModule, DeploymentManager, Module } from '@foundation/portal';


const context = import.meta.webpackContext(
  './',
  { 
    recursive: true, 
    regExp: /\.tsx$/ 
  }
);

@injectable({module: "mfe1"})
class Foo {
  constructor() { 
    console.log("new Foo  ");
  }
}

@Module({
  id: "mfe1",
  label: "MFE1 Module",
  version: "1.0.0",
  description: "MFE1 Micro Frontend Module",
})
export class MFE1Module extends AbstractModule {
    // override

    async setup(): Promise<void> {
      await super.setup()

      this.environment.get(DeploymentManager).checkLazyFeatures(this.getModuleName(), context);
    }
}


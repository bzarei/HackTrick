import "reflect-metadata";

// Import all components to trigger @Feature and @Module decorator registration

import "./MFE1Bar";
import "./MFE1FooLarge";
import "./MFE1FooSmall";
import "./DesktopNavigation";
import "./CapacitorIOSNavigation";

import "./Module";



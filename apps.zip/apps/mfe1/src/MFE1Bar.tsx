import React from "react";
import { Feature } from "@foundation/portal";

@Feature({
  id: "mfe1-bar",
  label: "Bar Page",
  icon: "shell:chat",
  description: "Bar feature page",
  path: "/mfe1/bar",
  tags: ["secret", "menu"],
  permissions: [],
  features: [],
  visibility: ["public"],
})
class MFE1Bar extends React.Component {
  throwError() : string {
    throw Error("ouch")
  }

  render() {
    return (
      <div>
        <p style={{ color: '#a0a0a0', lineHeight: '1.6' }}>
          This is the bar feature page from MFE1.
          {this.throwError()}
        </p>
      </div>
    );
  }
}

export default MFE1Bar;

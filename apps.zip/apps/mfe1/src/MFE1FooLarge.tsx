import React from "react";
import { Feature } from "@foundation/portal";

@Feature({
  id: "mfe1-foo-large",
  label: "Foo Page (Large)",
  icon: "shell:add",
  description: "Foo feature page for larger screens",
  path: "/mfe1/foo",
  tags: ["menu"],
  permissions: [],
  features: [],
  visibility: ["public"],
  clients: {
    minWidth: 1000,
  },
})
class MFE1FooLarge extends React.Component {
  render() {
    return (
      <div>
        <h2 style={{ color: "#ffffff", marginBottom: "1rem" }}>Foo (Large Screen)</h2>
        <p style={{ color: "#a0a0a0", lineHeight: "1.6" }}>
          This is the foo feature page optimized for screens ≥ 1000px.
        </p>
      </div>
    );
  }
}

export default MFE1FooLarge;
